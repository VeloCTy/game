using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private Rigidbody2D body;
    [SerializeField] private Transform tr;

    [SerializeField] private LayerMask groundCheckLayerMask;
    [SerializeField] private Vector3 groundCheckPointA;
    [SerializeField] private Vector3 groundCheckPointB;
    private bool isGrounded;

    [SerializeField] private float moveSpeed;
    [SerializeField] private float speedChange;
    [SerializeField] private float speedSnapDistance;

    [SerializeField] private float jumpPower;
    [SerializeField] private int jumpAmount;
    private int jumpsAvaileble;

    //[SerializeField] private bool inverseJump;
    //[SerializeField] private float inverseJumpMulti;

    [SerializeField] private float midair0KeepLimit;
    [SerializeField] private bool keepBehaviour;
    [SerializeField] private bool magnitudePreventAcceleration;
    [SerializeField] private float minPreventetAcceleration;
    public bool forceZeroKeep;



    void Start()
    {
        jumpsAvaileble = jumpAmount;
    }

    void Update()
    {
        isGrounded = IsGroundedFunc();
        JumpUpdate(jumpPower);
    }

    void FixedUpdate()
    {
        MoveFUpdate(moveSpeed);
    }



    bool IsGroundedFunc()
    {
      return Physics2D.OverlapArea(tr.position + groundCheckPointA, tr.position + groundCheckPointB, groundCheckLayerMask);

    }


    float FAbsolute(float i)
    {
        if (i < 0)
        {
            return -i;
        }
        return i;
    }

    float FSign(float i)
    {
        if (i > 0)
        return 1;
        else if (i < 0)
        return -1;
        else
        return 0;
    }



    void MoveFUpdate(float moveSpeed)
    {
        if (true)
        {
            float temporary = Input.GetAxisRaw("Horizontal") * moveSpeed;

            if (magnitudePreventAcceleration)
            {
                if (body.velocity.magnitude >= FAbsolute(temporary) + minPreventetAcceleration)
                {
                    if (temporary > 0)
                    temporary = minPreventetAcceleration;
                    else if (temporary < 0)
                    temporary = -minPreventetAcceleration;
                }
                else if (temporary > 0)
                temporary = temporary - body.velocity.magnitude + FAbsolute(body.velocity.x);
                else if (temporary < 0)
                temporary = temporary + body.velocity.magnitude - FAbsolute(body.velocity.x);
            }

            if ((forceZeroKeep && temporary == 0) || (keepBehaviour && ((temporary != 0 && temporary / FAbsolute(temporary) == body.velocity.x / FAbsolute(body.velocity.x) && FAbsolute(temporary) < FAbsolute(body.velocity.x)) || (midair0KeepLimit >= 0 && temporary == 0 && isGrounded == false && body.velocity.magnitude > midair0KeepLimit))))
            {
                temporary = body.velocity.x;
            }
            
            if (FAbsolute(temporary - body.velocity.x) > speedSnapDistance)
            {
                temporary = body.velocity.x + (temporary - body.velocity.x) * (speedChange / 100);
            }

            body.velocity = new Vector2(temporary, body.velocity.y);
        }
    }

    void JumpUpdate(float jumpPower)
    {
        UpdateJumpsAvailable();
        if (Input.GetButtonDown("Jump") && CanJump())
        {
            JumpAction();
            jumpsAvaileble--;
        }
    }

    void UpdateJumpsAvailable()
    {
        if (isGrounded)
        {
            jumpsAvaileble = jumpAmount;
        }
    }

    bool CanJump()
    {
        return (jumpsAvaileble != 0);
    }

    void JumpAction()
    {
        body.velocity = new Vector2(body.velocity.x, jumpPower);

        /*if (inverseJump && !isGrounded && Input.GetAxisRaw("Horizontal") == body.velocity.x / FAbsolute(body.velocity.x))
        {
            body.velocity = new Vector2(body.velocity.x * inverseJumpMulti, body.velocity.y);
        }*/
    }
}