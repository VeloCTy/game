using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Grapple : MonoBehaviour
{
    public bool grappled = false;

    [SerializeField] Transform playerTransform;
    [SerializeField] Rigidbody2D playerRgb;
    [SerializeField] PlayerMovement playerMovementScript;
    [SerializeField] Transform grapplePoint;

    [SerializeField] bool renderLine;
    [SerializeField] int linePoints;
    [SerializeField] LineRenderer lineRenderer;
    [SerializeField] bool removeGrappleOnDeath;

    private Transform point0;
    private Transform point1;

    [SerializeField] float grappleLenght;
    [SerializeField] float maxLenght;
    [SerializeField] float addLenght;

    private float arc;
    private float circumference;
    private Vector3 oldPlayerPos;
    [SerializeField] float t;

    [SerializeField] LayerMask validGrappleLM;
    [SerializeField] Vector3 hitAreaPointA;
    [SerializeField] Vector3 hitAreaPointB;

    [SerializeField] float keepSpeed;
    [SerializeField] bool restrainPosition;


    
    void Start()
    {
        grappled = true;

        point0 = grapplePoint;
        point1 = playerTransform;
    }

    void Update()
    {
        if (renderLine && grappled)
        UpdateLine(point0.position, point1.position);
        else
        ClearLine();

        if (!grappled)
        {
            if (Input.GetMouseButton(0))
            {
                Vector3 pos = GetMouseWorldPos();
                float lenght = (pos - playerTransform.position).magnitude + addLenght;

                if (IsValidGrapple(pos) && (lenght <= maxLenght))
                PlaceGrapple(pos, lenght);
            }
        }
        else if (!Input.GetMouseButton(0))
        {
            RemoveGrapple();
        }

        if (Input.GetKey(KeyCode.K))
        {
            playerRgb.velocity += Vector2.Perpendicular((grapplePoint.position - playerTransform.position).normalized).normalized * Vector2.Dot(Vector2.down, Vector2.Perpendicular((grapplePoint.position - playerTransform.position).normalized).normalized);
        }
    }

    void FixedUpdate()
    {
        if (grappled)
        UpdateDynamic();

        oldPlayerPos = playerTransform.position;
    }



    Vector3 GetMouseWorldPos()
    {
        Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mouseWorldPos.z = 0f;
        return mouseWorldPos;
    }

    float sign(float i)
    {
        if (i > 0)
        return 1;
        if (i < 0)
        return -1;
        return -1;
    }



    void PlaceGrapple(Vector2 point, float lenght)
    {
        grapplePoint.position = point;
        grappleLenght = lenght;
        circumference = 2 * lenght * Mathf.PI;
        grappled = true;

        playerMovementScript.forceZeroKeep = true;
    }


    void RemoveGrapple()
    {
        grappled = false;

        playerMovementScript.forceZeroKeep = false;
    }


    bool IsValidGrapple(Vector3 pos)
    {
        bool hit = Physics2D.OverlapArea(pos + hitAreaPointA, pos + hitAreaPointB, validGrappleLM);
        return hit;
    }


    void UpdateDynamic()
    {
        if (((playerTransform.position - new Vector3(grapplePoint.position.x, grapplePoint.position.y, 0))).magnitude > grappleLenght)
        {
            Vector2 grapplePerpendicular = Vector2.Perpendicular((oldPlayerPos - grapplePoint.position).normalized).normalized;
            float dotProduct = Vector2.Dot(playerRgb.velocity.normalized, grapplePerpendicular);
            playerRgb.velocity = grapplePerpendicular * (playerRgb.velocity.magnitude * dotProduct);

            arc = t * playerRgb.velocity.magnitude * sign(dotProduct) / circumference;
            playerTransform.position = new Vector3(grapplePoint.position.x, grapplePoint.position.y, 0) + Quaternion.Euler(0, 0, arc) * (oldPlayerPos - new Vector3(grapplePoint.position.x, grapplePoint.position.y, 0));

            grapplePerpendicular = Vector2.Perpendicular((oldPlayerPos - grapplePoint.position).normalized).normalized;
            playerRgb.velocity = grapplePerpendicular * playerRgb.velocity.magnitude * sign(dotProduct);
        }
    }

    
    void UpdateLine(Vector3 point0, Vector3 point1)
    {
        lineRenderer.positionCount = linePoints;
        lineRenderer.SetPosition(0, point0);
        for (int i = 1; i < linePoints - 1; i++)
        {
            lineRenderer.SetPosition(i, point0 + (point1 - point0) / (linePoints - 1) * i);
        }
        lineRenderer.SetPosition(linePoints - 1, point1);
    }


    void ClearLine()
    {
        lineRenderer.positionCount = 0;
    }


    void Death()
    {
        if (removeGrappleOnDeath)
        RemoveGrapple();
    }
}





/*
void UpdateDynamicPos()
    {
        Vector3 diffrence = grapplePoint.position - playerTransform.position;
        if (restrainPosition && diffrence.magnitude > grappleLenght)
        {
            playerTransform.position += diffrence.normalized * (diffrence.magnitude - grappleLenght);
        }
    }

    void UpdateDynamicVelocity()
    {

        Vector3 diffrence = grapplePoint.position - playerTransform.position;
        if (diffrence.magnitude > grappleLenght)
        {
            Vector2 grapplePerpendicular = Vector2.Perpendicular(diffrence.normalized).normalized;
            float dotProduct = Vector2.Dot(playerRgb.velocity.normalized, grapplePerpendicular);
            float diffrenceDotProduct = (1 - dotProduct) * keepSpeed;

            //Debug.Log("b");
            //Debug.Log(dotProduct);

            if (dotProduct > 0)
            {
            //Debug.Log(1 - dotProduct);
            dotProduct += (1 - dotProduct) * keepSpeed;
            Debug.Log("u");
            }
            else if (dotProduct < 0)
            {
            //Debug.Log(-1 - dotProduct);
            dotProduct += (-1 - dotProduct) * keepSpeed;
            Debug.Log("d");
            }

            //Debug.Log("a");
            //Debug.Log(dotProduct);
            //Debug.Log(playerTransform.position.y - grapplePoint.position.y);
            Debug.Log(grapplePerpendicular);
            Debug.Log(playerRgb.velocity);

            playerRgb.velocity = grapplePerpendicular * (playerRgb.velocity.magnitude * dotProduct);

            Debug.Log(playerRgb.velocity);
        }
    }
*/