using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillBadEntity : MonoBehaviour
{
    [SerializeField] Transform tr;
    [SerializeField] GameObject me;

    private Vector2 oldPos = new Vector2(0, 0);
    private Vector2 pos;

    [SerializeField] LayerMask layerMask;

    [SerializeField] int rate;
    private int cycle;

    [SerializeField] float delay;



    void Start()
    {
        cycle = rate;
    }

    void FixedUpdate()
    {
        if (cycle == 0)
        {
            pos = new Vector2(tr.position.x, tr.position.y);
            KillTouched();
            oldPos = pos;

            cycle = rate;
        }
        else
        {
            cycle--;
        }
    }



    void KillTouched()
    {
        GameObject hit = CheckTouched();
        if (hit && hit.GetComponent<LiveBody>())
        hit.SendMessage("GotHit", new HitObj(5, Vector2.zero), SendMessageOptions.DontRequireReceiver);
    }

    GameObject CheckTouched()
    {
        RaycastHit2D hit = Physics2D.Raycast(oldPos, (pos - oldPos).normalized, (pos - oldPos).magnitude, layerMask);
        if (hit)
        {
            return hit.collider.gameObject;
        }
        return null;
    }
}