using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DieWhenBelow : MonoBehaviour
{
    [SerializeField] int rate;
    public int cycle;

    [SerializeField] float yValue;

    private Transform tr;



    void Start()
    {
        cycle = rate;

        tr = this.gameObject.GetComponent<Transform>();
    }

    void FixedUpdate()
    {
        if (cycle <= 0)
        {
            KillIfBelow(yValue);

            cycle = rate;
        }
        else
        cycle--;
    }


    void KillIfBelow(float value)
    {
        if (tr.position.y <= value)
        {
            this.gameObject.SendMessage("VoidDeath", null, SendMessageOptions.DontRequireReceiver);
            this.gameObject.SendMessage("Death", null, SendMessageOptions.DontRequireReceiver);
        }
    }
}
