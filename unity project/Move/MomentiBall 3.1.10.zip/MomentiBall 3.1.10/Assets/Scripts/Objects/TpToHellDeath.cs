using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TpToHellDeath : MonoBehaviour
{
    [SerializeField] Vector3 hell;
    [SerializeField] int putInLayer;

    void Death()
    {
        this.gameObject.GetComponent<Transform>().position = hell;
        this.gameObject.layer = putInLayer;
    }
}
