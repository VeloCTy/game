using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Respawn : MonoBehaviour
{
    [SerializeField] Vector3 SpawnPos;
    [SerializeField] Transform spawnTransform;

    [SerializeField] float healTo;

    [SerializeField] bool keepVelocity;
    [SerializeField] Vector2 spawnVelocity;

    private Rigidbody2D body;



    void Start()
    {
        body = this.gameObject.GetComponent<Rigidbody2D>();
    }
    
    void Death()
    {
        if (spawnTransform)
        this.gameObject.GetComponent<Transform>().position = spawnTransform.position;
        else
        this.gameObject.GetComponent<Transform>().position = SpawnPos;

        if (healTo != 0)
        this.gameObject.GetComponent<LiveBody>().health = healTo;
        else
        this.gameObject.GetComponent<LiveBody>().health = this.gameObject.GetComponent<LiveBody>().maxHealth;
        this.gameObject.SendMessage("HealthChanged", null, SendMessageOptions.DontRequireReceiver);

        if (!keepVelocity)
        body.velocity = spawnVelocity;
    }
}
