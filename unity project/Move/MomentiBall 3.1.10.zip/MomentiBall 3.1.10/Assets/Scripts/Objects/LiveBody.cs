using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class LiveBody : MonoBehaviour
{
    [SerializeField] float startHealth;
    [SerializeField] bool enableKnockback;
    [SerializeField] bool knockbackAdditive;
    [SerializeField] public bool invulnerable;
    [SerializeField] bool stayOnDeath;

    [SerializeField] public bool bindInvulnerable;
    [SerializeField] public int liveBinds;

    [SerializeField] public int maxHealth;


    public float health;

    private Rigidbody2D rg;
    private GameManagerScript gameManagerScript;

    private Vector3 spawnPos;



    void Start()
    {
        health = startHealth;
        if (this.gameObject.GetComponent<Rigidbody2D>())
        rg = this.gameObject.GetComponent<Rigidbody2D>();
        gameManagerScript = GameObject.FindWithTag("GameController").GetComponent<GameManagerScript>();
    }


    void GotHit(HitObj hit)
    {
        if (!invulnerable && !bindInvulnerable)
        this.health -= hit.dmg;
        if (enableKnockback && rg)
        {
            if (!knockbackAdditive)
            rg.velocity = hit.knockback;
            else
            rg.velocity += hit.knockback;
        }
        this.gameObject.SendMessage("HealthChanged", null, SendMessageOptions.DontRequireReceiver);
    }


    void HealthChanged()
    {
        UpdateDeathState();
    }

    void UpdateDeathState()
    {
        if (health <= 0)
        this.gameObject.SendMessage("Death", null, SendMessageOptions.DontRequireReceiver);
    }


    void Death()
    {
        //Debug.Log("dead, no big suprise");
        if (!stayOnDeath)
        Destroy(this);
    }


    public void UpdateBindInvulnerable()
    {
        if (liveBinds > 0)
        bindInvulnerable = true;
        else
        bindInvulnerable = false;
    }
}
