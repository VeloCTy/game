using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicFadeDeath : MonoBehaviour
{
    [SerializeField] float decay;
    [SerializeField] LayerMask putInLayer;
    [SerializeField] bool keepRigidbody;



        void Death()
    {
        if (this.gameObject.GetComponent<Collider2D>())
        Destroy(this.gameObject.GetComponent<Collider2D>());

        if (this.gameObject.GetComponent<Rigidbody2D>() && !keepRigidbody)
        Destroy(this.gameObject.GetComponent<Rigidbody2D>());

        if (this.gameObject.GetComponent<SpriteRenderer>())
        Destroy(this.gameObject.GetComponent<SpriteRenderer>());

        this.gameObject.layer = putInLayer.value;

        if (this.gameObject.GetComponent<Transform>().childCount > 0)
        for (int i = 0; i < this.gameObject.GetComponent<Transform>().childCount; i++)
        this.gameObject.GetComponent<Transform>().GetChild(i).SendMessage("Death", null, SendMessageOptions.DontRequireReceiver);

        Destroy(this.gameObject, decay);
    }
}
