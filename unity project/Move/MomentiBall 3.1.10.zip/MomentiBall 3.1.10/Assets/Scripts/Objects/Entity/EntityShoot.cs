using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EntityShoot : MonoBehaviour
{
    [SerializeField] Transform parent;
    [SerializeField] Transform target;
    [SerializeField] Transform shooter;
    [SerializeField] GameObject bulletPreset;

    [SerializeField] Vector2 shootOffset;

    [SerializeField] float rate;
    [SerializeField] float initialWait;
    [SerializeField] float bulletSpeed;

    [SerializeField] bool destroyOnDeath;
    public bool inactive;

    private bool ready = false;



    void Start()
    {
        if (!target)
        {
            target = GameObject.FindWithTag("Player").GetComponent<Transform>();
        }
        if (!parent)
        {
            parent = GameObject.FindWithTag("Projectiles").GetComponent<Transform>();
        }
        

        StartCoroutine(SetReadyToTrueAfterDelay(initialWait));
    }

    private IEnumerator SetReadyToTrueAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        ready = true;
    }

    void Update()
    {
        if (ready && !inactive)
        {
            Shoot();

            ready = false;
            StartCoroutine(SetReadyToTrueAfterDelay(rate));
        }
    }



    void Shoot()
    {
        GameObject bullet = Instantiate(bulletPreset, parent);
        Transform bulletTr = bullet.GetComponent<Transform>();
        Rigidbody2D bulletRG =  bullet.GetComponent<Rigidbody2D>();
        bulletTr.position = new Vector3(shooter.position.x + shootOffset.x, shooter.position.y + shootOffset.y, 0);
        bulletRG.velocity = (new Vector2(target.position.x, target.position.y) - new Vector2(shooter.position.x, shooter.position.y) - shootOffset).normalized * bulletSpeed;
        bulletTr.rotation = Quaternion.FromToRotation(transform.up, bulletRG.velocity);
    }


    void Death()
    {
        if (destroyOnDeath)
        Destroy(this);
    }
}
