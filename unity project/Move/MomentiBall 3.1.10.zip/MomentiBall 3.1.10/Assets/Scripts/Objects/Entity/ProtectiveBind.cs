using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProtectiveBind : MonoBehaviour
{
    [SerializeField] LiveBody body;
    [SerializeField] public bool renderLine;
    [SerializeField] bool staticLine;
    [SerializeField] int linePoints;
    [SerializeField] LineRenderer lineRenderer;
    [SerializeField] bool destroyOnDeath;

    private Transform point0;
    private Transform point1;


    
    void Start()
    {
        point0 = this.gameObject.GetComponent<Transform>().parent.GetComponent<Transform>();
        point1 = body.gameObject.GetComponent<Transform>();
        if (body)
        {
            body.liveBinds++;
            body.UpdateBindInvulnerable();

            if (renderLine)
            UpdateLine(point0.position, point1.position);
        }
    }

    void Update()
    {
        if (renderLine && !staticLine && body)
        UpdateLine(point0.position, point1.position);
    }



    void UpdateLine(Vector3 point0, Vector3 point1)
    {
        lineRenderer.positionCount = linePoints;
        lineRenderer.SetPosition(0, point0);
        for (int i = 1; i < linePoints - 1; i++)
        {
            lineRenderer.SetPosition(i, point0 + (point1 - point0) / (linePoints - 1) * i);
        }
        lineRenderer.SetPosition(linePoints - 1, point1);
    }


    void Death()
    {
        if (body)
        {
        body.liveBinds--;
        body.UpdateBindInvulnerable();
        }
        if (destroyOnDeath)
        Destroy(this.gameObject);
        else
        renderLine = false;
    }
}
