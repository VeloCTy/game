using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.Universal;

public class ScreenEffectsInPlayer : MonoBehaviour
{
    [SerializeField] Light2D redHurtEffectComponent;
    [SerializeField] float redHurtEffectIntensity;
    [SerializeField] float redHurtEffectWeakenIntensity;

    private LiveBody body;



    void Start()
    {
        body = this.gameObject.GetComponent<LiveBody>();
    }

    void HealthChanged()
    {
        if (redHurtEffectComponent)
        {
            redHurtEffectComponent.intensity = (body.maxHealth - body.health) / body.maxHealth * redHurtEffectIntensity;
            
            if (redHurtEffectComponent.gameObject.GetComponent<MainGlobalLightWeakener>())
            redHurtEffectComponent.gameObject.GetComponent<MainGlobalLightWeakener>().SetWeaken((body.maxHealth - body.health) / body.maxHealth * redHurtEffectWeakenIntensity);
        }
    }
}
