using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainGlobalLightWeakener : MonoBehaviour
{
    [SerializeField] public float weaken;
    [SerializeField] GlobalLightWeakener victim;

    public void SetWeaken(float value)
    {
        weaken = value;

        if (victim)
        victim.SendMessage("UpdateWeak", null, SendMessageOptions.DontRequireReceiver);
    }
}
