using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.Universal;

public class GlobalLightWeakener : MonoBehaviour
{
    [SerializeField] MainGlobalLightWeakener[] Weakeners;
    [SerializeField] float normalIntensity;

    void UpdateWeak()
    {
        float totalWeaken = 0;

        for (int i = 0; i < Weakeners.Length; i++)
        totalWeaken += Weakeners[i].weaken;

        this.gameObject.GetComponent<Light2D>().intensity = normalIntensity - totalWeaken;
    }
}
