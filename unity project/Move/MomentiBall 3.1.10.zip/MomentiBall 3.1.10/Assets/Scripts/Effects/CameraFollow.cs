using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public class CameraFollow : MonoBehaviour
{
    private Transform tr;
    Transform pl = null;

    [SerializeField] Vector2 maxCameraOffset;
    [SerializeField] Vector2 minCameraOffset;
    [SerializeField] float followPercentageSpeed;
    [SerializeField] float followSpeed;



    void Start()
    {
        
        tr = this.GetComponent<Transform>();
        
    }

    void Update()
    {
        if (pl == null)
        {
            UpdatePlayer();
        }

        if (pl != null)
        {
            UpdateCamera();
        }
    }



    void UpdatePlayer()
    {
        GameObject a = GameObject.FindWithTag("Player");
        if (a != null)
        {
            pl = a.GetComponent<Transform>();
        }
    }


    void UpdateCamera()
    {
        MoveCamera(CheckNewCameraPos(minCameraOffset, maxCameraOffset));
    }

    Vector2 CheckNewCameraPos(Vector2 minOffset, Vector2 maxOffset)
    {
        float resultX;
        float resultY;

        Vector2 minPos = minOffset + new Vector2(tr.position.x, tr.position.y);
        Vector2 maxPos = maxOffset + new Vector2(tr.position.x, tr.position.y);

        if (pl.position.x < minPos.x)
        {
            resultX = minOffset.x;
        }
        else if (pl.position.x > maxPos.x)
        {
            resultX = maxOffset.x;
        }
        else
        {
            resultX = pl.position.x - tr.position.x;
        }

        if (pl.position.y < minPos.y)
        {
            resultY = minOffset.y;
        }
        else if (pl.position.y > maxPos.y)
        {
            resultY = maxOffset.y;
        }
         else
        {
            resultY = pl.position.y - tr.position.y;
        }

        
        return new Vector2(pl.position.x, pl.position.y) - new Vector2(resultX, resultY);
    }

    void MoveCamera(Vector2 pos)
    {
        /*
        Vector2 camPos = new Vector2(tr.position.x, tr.position.y);
        Vector2 diffrence = pos - camPos;

        Vector2 change = diffrence * followPercentageSpeed / 100;
        tr.position += new Vector3(change.x, change.y, 0);
        */
    
        //tr.position += new Vector3(pos.x - tr.position.x, pos.y - tr.position.y, 0) * followPercentageSpeed / 100;
        //tr.position += new Vector3(pos.x - tr.position.x, pos.y - tr.position.y, 0) * (1 - Mathf.Pow(0.5f, Time.deltaTime * followPercentageSpeed / 100));
        //(B-A)*t+A = A-A*t+B*t = A*(1-t)+B*t = lerp(A, B, t)
        tr.position = Vector3.Lerp(new Vector3(pos.x, pos.y, tr.position.z), new Vector3(tr.position.x, tr.position.y, tr.position.z), Mathf.Pow(followPercentageSpeed, Time.deltaTime * followSpeed));
    }
}
