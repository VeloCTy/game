using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManagerScript : MonoBehaviour
{
    [SerializeField] Transform levelParent;
    [SerializeField] GameObject level;
    [SerializeField] TMPro.TextMeshProUGUI text;
    private GameObject currentLevel;

    public float gameStart;



    void Start()
    {
        LoadLevel(level);
    }

    void Update()
    {
        
    }



    void EndGame(string message)
    {
        Say(message);

        LoadLevel(level);
    }


    void LoadLevel(GameObject inLevel)
    {
        Destroy(currentLevel);
        currentLevel = Instantiate(inLevel, levelParent);
        gameStart = Time.time;
    }


    void Say(string IMessage)
    {
        text.text = IMessage;
    }
}



public class HitObj
{
    public float dmg;
    public Vector2 knockback;
    
    //public HitObj ExecWithPlayer;

    public HitObj(float inDmg, Vector2 inKnockback)
    {
        dmg = inDmg;
        knockback = inKnockback;
        //ExecWithPlayer = InExecWithPlayer;
    }
}