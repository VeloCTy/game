using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Launch : MonoBehaviour
{
    [SerializeField] Vector2 velocity;
    [SerializeField] bool additive;



    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.GetComponent<Rigidbody2D>())
        if (!additive)
        other.gameObject.GetComponent<Rigidbody2D>().velocity = velocity;
        else
        other.gameObject.GetComponent<Rigidbody2D>().velocity += velocity;
    }
}
