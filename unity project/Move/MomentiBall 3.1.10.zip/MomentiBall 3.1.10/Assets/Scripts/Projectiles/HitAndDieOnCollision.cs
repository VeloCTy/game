using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitAndDieOnCollision : MonoBehaviour
{
    [SerializeField] float dmg;
    [SerializeField] float knockbackMultiplier;



    void OnTriggerEnter2D(Collider2D hit)
    {
        hit.gameObject.SendMessage("GotHit", new HitObj(dmg, this.gameObject.GetComponent<Rigidbody2D>().velocity * knockbackMultiplier), SendMessageOptions.DontRequireReceiver);

        LocalDie();
    }


    private void LocalDie()
    {
        this.gameObject.SendMessage("Death", null, SendMessageOptions.DontRequireReceiver);
    }

    void Death()
    {
        Debug.Log("hit");
        Destroy(this);
    }
}



/*public class HitObj
{
    public float dmg;
    public Vector2 knockback;
    
    public HitObj ExecWithPlayer;

    public HitObj(float inDmg, Vector2 inKnockback, HitObj InExecWithPlayer = null)
    {
        dmg = inDmg;
        knockback = inKnockback;
        ExecWithPlayer = InExecWithPlayer;
    }
}*/