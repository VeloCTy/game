using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndGameOnDeath : MonoBehaviour
{
    [SerializeField] string message;
    [SerializeField] TimerManager timer;
    private GameManagerScript manager;



    void Start()
    {
        manager = GameObject.FindWithTag("GameController").GetComponent<GameManagerScript>();
    }



    void Death()
    {
        manager.SendMessage("EndGame", message + timer.time.ToString(), SendMessageOptions.DontRequireReceiver);
    }
}
