using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimerManager : MonoBehaviour
{
    public float time = 0f;
    public float levelStart;
    private float lastUpdate;
    private float timePassed;

    public float speed = 1f;



    void Start()
    {
        levelStart = Time.time;
        lastUpdate = Time.time;
    }

    void Update()
    {
        timePassed = Time.time - lastUpdate;
        time += timePassed * speed;

        lastUpdate = Time.time;
    }


    void AddTime(float value)
    {
        time += value;
    }
}
