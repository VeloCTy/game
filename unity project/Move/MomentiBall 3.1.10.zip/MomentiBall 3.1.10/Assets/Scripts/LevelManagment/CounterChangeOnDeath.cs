using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CounterChangeOnDeath : MonoBehaviour
{
    [SerializeField] CounterLevelManager manager;
    [SerializeField] float value;



    void Death()
    {
        //Debug.Log(value);
        manager.ChangeCounter(value);
    }
}
