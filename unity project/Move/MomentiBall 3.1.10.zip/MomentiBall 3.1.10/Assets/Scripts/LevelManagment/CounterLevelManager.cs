using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CounterLevelManager : MonoBehaviour
{
    [SerializeField] float counter;
    [SerializeField] string message;
    [SerializeField] TimerManager timer;

    private GameManagerScript manager;



    void Start()
    {
        manager = GameObject.FindWithTag("GameController").GetComponent<GameManagerScript>();
    }



    public void ChangeCounter(float value)
    {
        counter += value;

        if (counter <= 0)
        {
            manager.SendMessage("EndGame", message + timer.time.ToString(), SendMessageOptions.DontRequireReceiver);
        }
    }
}
